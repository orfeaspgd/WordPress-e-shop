<div id="{{uc_id}}"  class="product-list-cont{{uc_filtering_addclass}}{{remote_parent.class}} {{uc_dynamic_popup_class}}" {{uc_filtering_attributes|raw}} {{remote_parent.attributes|raw}} >
	<ul class="product-list uc-items-wrapper">

		{{put_items()}}


	</ul>
</div>


{% if show_empty_message == "true" %}

  <div id="{{uc_id}}_empty_message" class="ue-no-posts-found" {% if uc_num_items > 0 %} style="display:none" {% endif %}>{{no_posts_found|raw}}</div>

{% endif %}