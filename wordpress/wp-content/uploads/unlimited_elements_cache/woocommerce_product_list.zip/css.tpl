#{{uc_id}}  *{
	box-sizing:border-box;
}

#{{uc_id}} ul
{
  padding:0px;
  margin:0px;
  display:grid;
}
#{{uc_id}} .product-img{
	
    flex-grow:0;
    flex-shrink:0;
    display:flex;
    align-items:center;
    justify-content:center;
    position:relative;
    overflow:hidden;
}

#{{uc_id}} .product-img img
{
  display:block;
}

 
#{{uc_id}} .product-items{
	display: flex;
	align-items:{{content_align}};
}


#{{uc_id}} .product-items:last-child{
    margin-bottom:0px;
}

#{{uc_id}} .product-text{
flex-grow:1;
}

.product-text-name
{
  font-size: 21px;
}

#{{uc_id}} .product-text-name{
	display: block;
	text-decoration: none;
	
}

#{{uc_id}} .uc-buttons a {
	cursor: pointer;
	text-decoration: none;
    text-align:center;
    transition:0.3s;
}

.uc-button-addcart.added
{
  display:none !important;
}

#{{uc_id}} .ue_woocommerce_product_list_badge
{
  display:inline-flex;
  align-items:center;
  justify-content:center;
}

.ue_woocommerce_product_grid_out_of_stock_label, .ue_woocommerce_product_list_badge
{
  font-size:12px;
}

#{{uc_id}} .ue_woocommerce_product_grid_out_of_stock_label{
 display:inline-flex;
 align-items:center;
 justify-content:center;
}

#{{uc_id}} .product-img-overlay
{
  position:absolute;
  top:0;
  bottom:0;
  right:0;
  left:0;
  flex-direction:column;
  display:flex;
  align-items:center;
  transition:0.3s;
}

#{{uc_id}} .product-img-overlay .uc-buttons
{
  text-align:center;
  width:100%;
}

{% if badge == "image" %}
    #{{uc_id}} .ue_woocommerce_product_list_badge
	{
      position:absolute;
      {{vertical_snap}}:{{label_vertical_distance}}px;
      {{horizontal_snap}}:{{label_horizontal_distance}}px;
    }
	#{{uc_id}} .ue_woocommerce_product_grid_out_of_stock_label{
      position: absolute;
      {{horizontal_snap}}:{{label_horizontal_distance}}px;
      {{vertical_snap}}:{{label_vertical_distance}}px;
      z-index: 1;
	}
{% endif %}


{% if collapse_on_mobile == "true" %}

@media only screen and (max-width: {{collapse_from_resolution}}px) {
  #{{uc_id}} .product-items{
    flex-wrap: wrap;
   }
}


{% endif %}

#{{uc_id}} .jet-wishlist-button__container{
  	margin-top:10px;
}