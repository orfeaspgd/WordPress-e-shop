jQuery(document).ready(function(){
    
  var objGrid = jQuery("#{{uc_id}}");
    
  var objRemoteOptions = {
    	class_items:"product-items",
    	class_active:"ue-active-item",
      	add_set_active_code:false
  };
  
  {{ucfunc("put_remote_parent_js","objGrid","objRemoteOptions")}}  
 
});