{% if item.product.woo_sale_price is empty %}
	#{{item.item_id}} .uc_sale_currency
    {
      display:none
    }
{% else %} 
	#{{item.item_id}} .uc_regular_price
    {
      text-decoration:line-through !important;
    }
{% endif %}