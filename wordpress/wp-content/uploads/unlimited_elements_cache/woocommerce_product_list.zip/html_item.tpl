<li class="product-items" style="overflow:hidden;" id="{{item.item_id}}"> 

  	{% if(enable_third_party_integrations == "true")%}
    	{{do_action('ue_woocommerce_product_integrations', item.product.id)}}
	{%endif%}
  
            {% if show_image == "true" %}
             	<div class="product-img" href="{{item.product.link}}">
                  
                  
                  {% if item.product.image is empty %}
                      <img src="{{empty_image_placeholder}}" {{empty_image_placeholder_attributes|raw}}>
                  {% else %} 
                      <img src="{{item.product.image}}" {{item.product.image_attributes|raw}}>
                  {% endif %}	
                  
                   
                 
                   {% if badge == "image" %}
                   	{% if show_labels == "true" %}
                      {% if(item.product.woo_stock_status == "outofstock") %}
                        <div class="ue_woocommerce_product_label ue_woocommerce_product_grid_out_of_stock_label">{{out_of_stock_text|raw}}</div>
                      {% else %}
                        {% if item.product.woo_sale_price is empty %}
                        {% else %}
                           <div class="ue_woocommerce_product_label ue_woocommerce_product_list_badge">
                             {{sale_label|raw}} 
                             {% if show_sale_precent_in_label == "true" %}
                               {{item.product.woo_discount_percent}}%
                             {% endif %}
                             {{sale_label_end_text|raw}}
                           </div>
                        {% endif %}
                      {% endif %}
                    {% endif %}
                   {% endif %} 
                  
                  <div class="product-img-overlay">
                    <div class="uc-buttons">
                      {% if (show_product_button == "true") and (product_button_type == "image_overlay") %}
                      
                      	<a href="{{item.product.link}}" {{item.product.dynamic_popup_link_attributes|raw}} class="product-text-btn {{item.product.dynamic_popup_link_class}}" > {{product_page_button_text|raw}}</a> 
                      
                      {% endif %}
                      
                      {% if cart_button == "image_overlay" %} 
                  
                      {% if(item.product.woo_type == "variable") %}
                          {% set buttonAddCartTextCombined = select_options_button_text %}        	
                      {% else %}
                          {% set buttonAddCartTextCombined = cart_button_text %}
                      {% endif %}
                                    
                          <a {{item.product.woo_addcart_ajax_attributes|raw}}>{{ buttonAddCartTextCombined|raw}}</a>                  
                                    	
                  {% endif %}
                    </div>   
                  </div>
                </div> 
  
  				 <div class="uc-product-items-spacer"></div>
            {% endif %}	
			
           

			<div class="product-text"> 
              
              {% if badge == "content" %}
               {% if show_labels == "true" %}
              	{% if(item.product.woo_stock_status == "outofstock") %}
                  <div class="ue_woocommerce_product_label ue_woocommerce_product_grid_out_of_stock_label">{{out_of_stock_text|raw}}</div>
                {% else %}
                  {% if item.product.woo_sale_price is empty %}
                  {% else %}
                     <div class="ue_woocommerce_product_label ue_woocommerce_product_list_badge">
                       {{sale_label|raw}} 
                       {% if show_sale_precent_in_label == "true" %}
                         {{item.product.woo_discount_percent}}%
                       {% endif %}
                       {{sale_label_end_text|raw}}
                     </div>
                  {% endif %}
              	{% endif %}
               {% endif %}	
              {% endif %}
              
              {% if category == "above" %}
				<div class="ue-product-category"><a  href="{{item.product.category_link}}">{{item.product.category_name}} </a></div>
              {% endif %}
              
              {% if show_title == "true" %}
				<a class="product-text-name" href="{{item.product.link}}">{{item.product.title|raw}} </a>
              {% endif %}	
              
              {% if category == "under" %}
				<div class="ue-product-category"><a class="ue-product-category" href="{{item.product.category_link}}">{{item.product.category_name}} </a></div>
              {% endif %}
              
              {% if show_description == "short" %}
              <div class="product-short-description">{{item.product.intro|raw}}</div>
              {% endif %}
              
              {% if show_description == "full" %}
              <div class="product-short-description">{{item.product.intro_full|truncate(10000)}}</div>
              {% endif %}
              
              {% if show_rating == "true" %}
              <div class="product-rating">
                {%for staritem in item.product.woo_rating_stars %}                
                    <i class="{{staritem.class}}"></i>
                {% endfor %}
              </div>
              {% endif %}
              
              <div class="product-text-wrapper uc-prices">
         
                {% if show_regular_price == "true" and item.product.woo_sale_price is not empty %}  
					
                      {%if item.product.woo_type == "variable" %}

                            {% if item.product.woo_regular_price_from == item.product.woo_regular_price_to %}
                                <span class="product-text-price uc_regular_price">{{item.product.woo_regular_price|wc_price|raw}}</span> <span class="uc_price_spacer" style="display:inline-block;"></span> 
                            {% else %}
                                <span class="product-text-price uc_regular_price">{{item.product.woo_regular_price_from|wc_price(item.product.woo_regular_price_from_id)|raw}}</span> - <span class="product-text-price uc_regular_price">{{item.product.woo_regular_price_to|wc_price(item.product.woo_regular_price_to_id)|raw}}</span><span class="uc_price_spacer" style="display:inline-block;"></span> 
                            {% endif %}
                      {%else%}
                            <span class="product-text-price uc_regular_price">{{item.product.woo_regular_price|wc_price|raw}}</span> <span class="uc_price_spacer" style="display:inline-block;"></span> 
                       {%endif%}
                    {% endif %}
                    
                 {% if show_sale_price == "true" %}
					{%if item.product.woo_type == "variable" %}
                          {% if item.product.woo_price_from == item.product.woo_price_to %}
								<span class="product-text-price uc_sale_price">{{item.product.woo_price|wc_price|raw}}</span> 
                          {% else %}
								<span class="product-text-price uc_sale_price">{{item.product.woo_price_from|wc_price(item.product.woo_price_from_id)|raw}}</span> - <span class="product-text-price uc_sale_price">{{item.product.woo_price_to|wc_price(item.product.woo_price_to_id)|raw}}</span>
						  {% endif %}
					{%else%}
						<span class="product-text-price uc_sale_price">{{item.product.woo_price|wc_price(item.product.id)|raw}}</span> 
				    {%endif%}
				{% endif %}
                
              </div> 
              
               
                <div class="product-text-wrapper uc-buttons"> 
                  
                  {% if (show_product_button == "true") and (product_button_type == "content") %} 
                      
                      	<a {{item.product.dynamic_popup_link_attributes|raw}} class="product-text-btn {{item.product.dynamic_popup_link_class}}" > {{product_page_button_text|raw}}</a> <span class="uc_btn_spacer" style="display:inline-block;"></span> 
                  
                  {% endif %}
                  
                  {% if cart_button == "content" %} 
                  
                      {% if(item.product.woo_type == "variable") %}
                          {% set buttonAddCartTextCombined = select_options_button_text %}        	
                      {% else %}
                          {% set buttonAddCartTextCombined = cart_button_text %}
                      {% endif %}
                                    
                          <a {{item.product.woo_addcart_ajax_attributes|raw}}>{{ buttonAddCartTextCombined|raw}}</a>                  
                                    	
                  {% endif %}
                
              </div>
                
{% if(enable_third_party_integrations == "true")%}
	{{do_action('ue_woocommerce_product_integrations_bottom', item.product.id)}}
{%endif%}
              
			</div>
</li>